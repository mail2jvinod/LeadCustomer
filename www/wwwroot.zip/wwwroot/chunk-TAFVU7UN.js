import{b as a,c as b}from"./chunk-NMYJD6OP.js";import"./chunk-JHI3MBHO.js";export{a as GESTURE_CONTROLLER,b as createGesture};
