var n=function(r){return r.currency="$",r}(n||{});export{n as a};
