import{a}from"./chunk-2HPOLAWI.js";import"./chunk-ZWP5B5SO.js";import"./chunk-7HH3MQBB.js";import"./chunk-JHI3MBHO.js";export{a as VegNonvegIndicatorComponent};
